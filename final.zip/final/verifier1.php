<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">

<head>

    <title>Verifier Etape</title>
    <link rel="icon" href="navi.ico" type="image/x-icon">
    <meta content="text/html;charset=utf-8" http-equiv="content-type"/>
    <link href="style.css" type="text/css" media="screen" rel="stylesheet"/>
    <header>
        <h1>NAVI_GPS</h1>
    </header>
</head>

<body>
  <div class="title">
      <h>  Verifier etapes !</h>
  </div>

  <div class="set" style="text-align: left">
      <input type="button" id="but1" onclick="window.location.href='information.html'"></input>
      <input type="button" id="but2" onclick="histoire"></input>
  </div>
  <div class="Divetat" style="text-align: right">
    <input type="button" id="but3" onclick="window.location.href='homepage.html'" value="Acceuil">
      <input type="button" id="but3" onclick="window.location.href='login.html'" value="Login"><!--未登陆时显示-->
      <input type="button" id="but3" onclick="logout" value="Logout"><!--登陆时显示-->
  </div>




  <div class="nextbox">
    <form method="post" action="verifier1.php">
    <?php
    session_start();
    $resultuse=$_SESSION['cheminuse'];
    $i=$_SESSION['fois'];
    if($i<sizeof($resultuse[0][3])) {
    print_r($resultuse);
    echo "</br>Votre etape est la ville ";
    print_r($resultuse[0][0][$i]);
    echo "</br>Votre etape est la route ";
    print_r($resultuse[0][3][$i]);
    echo "</br>";
    $_SESSION['fois']= $i+1;
    }
    else {
      echo "<script>alert('vous avez fini tous etape')</script>";
      header("refresh:0;url=homepage.html");
    }
    echo "<input type='submit' id='but3' value='verifier'>";


    // function addhistoire($username,$histoire){
    //   $dom = new DOMDocument();
    //   $dom->formatOutput = true;
    //   $dom->load('./Userlist.xml');
    //   $utilisateurs=$dom->getElementsByTagName('List');
    //
    //   foreach ($utilisateurs as $i) {
    //     $usernames=$i->getElementsByTagName('username');
    //     $username=$usernames->item(0)->nodeValue;
    //
    //     if($username==$susername){
    //
    //
    //         $utilisateur =$dom->getElementsByTagName('utilisateur')->item(0);
    //         $preference = $dom->createElement('preference');
    //         $element1 = $dom->createElement('nompasse',$postnompasse);
    //         foreach ($posttypeville as $k) {
    //           $element2 = $dom->createElement('typeville',$k);
    //           $preference->appendChild($element2);
    //         }
    //         foreach ($posttyperoute as $k) {
    //           $element3 = $dom->createElement('typeroute',$k);
    //           $preference->appendChild($element3);
    //         }


            $element4 = $dom->createElement('touristique',$posttouristique);
            $element5 = $dom->createElement('radar',$postradar);
            $element6 = $dom->createElement('payant',$postpayant);
            $element7 = $dom->createElement('chemin',$postchemin);
            $preference->appendChild($element1);
            // $preference->appendChild($element2);
            // $preference->appendChild($element3);
            $preference->appendChild($element4);
            $preference->appendChild($element5);
            $preference->appendChild($element6);
            $preference->appendChild($element7);
            $utilisateur->appendChild($preference);

            $dom->save('./utilisateur.xml');
            header("refresh:0;url=homepage.html");
            break;
          }

    }
    ?>
    <input type='button' id='but3' value='perdu' onclick="window.location.href='information.html'">
  </form>
  </div>
</br>


</body>
