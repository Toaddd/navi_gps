function information(){
   window.location.href='./information.html';
}

function histoire(){
   window.location.href='./histoire.html';
}

function login(){
   window.location.href='./login.html';
}

function logout(){
   $.session.clear(); 
 }
