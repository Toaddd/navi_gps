<?php

function verif($mdp){
    $ok = true;
    $dom = new DOMDocument();
    $dom->load('./utilisateur.xml');
    $utilisateur=$dom->getElementsByTagName('utilisateur');

    foreach ($utilisateur as $i) {
        $usernames=$i->getElementsByTagName('username');
        $username=$usernames->item(0)->nodeValue;
        if($username==$user){
            $ok = false;
            break;
        }
        else{
            continue;
        }
    }

    return $ok;
}

?>